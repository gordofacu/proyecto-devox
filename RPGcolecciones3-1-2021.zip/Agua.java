public class Agua extends Liquido {

    public Agua () {
        setNombre("Agua");
        setPeso(25);
    }
    
}
