public class ContenedorVacioException extends Exception {
    private static final long serialVersionUID = 2L;

    public ContenedorVacioException(String msg) {
        super(msg);
    }
}
