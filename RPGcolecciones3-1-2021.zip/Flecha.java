public class Flecha extends Elemento implements Portable {

    public Flecha() {
        setNombre("Flecha");
        setPeso(3);
    }
    
}
