public class Hueso extends Elemento implements Portable {

    public Hueso() {
        setNombre("Hueso");
        setPeso(1);
    }
    
}