public class Pocima extends Liquido {

    public Pocima(String nombre, Integer peso) {
        setNombre("Pocima de " + nombre);
        setPeso(peso);
    }
    
}
