public class AccionNoPermitidaException extends Exception {
    private static final long serialVersionUID = 3L;

    public AccionNoPermitidaException(String msg) {
        super(msg);
    }

}